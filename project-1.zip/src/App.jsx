// App.js

import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const socket = io('http://test.paradoxmp.com:8081'); // Replace with your Node.js server URL

const App = () => {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    // Listen for incoming messages
    socket.on('receive_message', (data) => {
      setMessages((prevMessages) => [...prevMessages, { text: data, self: false }]);
    });

    // Clean up the socket connection on component unmount
    return () => {
      socket.disconnect();
    };
  }, []);

  const sendMessage = () => {
    if (newMessage.trim() !== '') {
      // Emit a message to the server
      socket.emit('send_message', newMessage);

      // Update the local state
      setMessages((prevMessages) => [...prevMessages, { text: newMessage, self: true }]);
      setNewMessage('');
    }
  };

  return (
    <div>
      <div style={{ height: '400px', border: '1px solid #ccc', overflowY: 'scroll' }}>
        {messages.map((message, index) => (
          <div key={index} style={{ padding: '5px', textAlign: message.self ? 'right' : 'left' }}>
            {message.self ? "You :" + message.text : socket.id + " : "+ message.text}
          </div>
        ))}
      </div>
      <div>
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default App;